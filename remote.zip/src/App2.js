import './App.css';

function App() {
  return (
    <div className="App">
      <h1>This is remote 2</h1>
    </div>
  );
}

export default App;
