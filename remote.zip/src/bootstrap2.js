import React from 'react'

const RemoteComponent = () => {
  return (
    <div>RemoteComponent 2</div>
  )
}

export default RemoteComponent