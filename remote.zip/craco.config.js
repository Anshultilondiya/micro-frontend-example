const { ModuleFederationPlugin } = require("webpack").container;

module.exports = {
  devServer: {
    port: 5001,
  },
  webpack: {
    plugins: {
      add: [
        new ModuleFederationPlugin({
          name: "TodoModule",
          exposes: {
            "./Todo": "./src/App",
            "./Todo2": "./src/App2",
          },
          filename: "remoteEntry.js",
          shared: {
            react: { singleton: true },
            "react-dom": { singleton: true },
          },
        }),
      ],
    },
    configure: (webpackConfig) => ({
      ...webpackConfig,
      output: {
        ...webpackConfig.output,
        publicPath: "auto",
      },
    }),
  },
};