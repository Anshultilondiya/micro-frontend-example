const { ModuleFederationPlugin } = require("webpack").container;

module.exports = {
  devServer: {
    port: 5050,
  },
  webpack: {
    plugins: {
      add: [
        new ModuleFederationPlugin({
          name: "host",
          remotes: {
            TodoModule: "TodoModule@http://localhost:5001/remoteEntry.js",
          }, 
          shared: {
            react: { singleton: true },
            "react-dom": { singleton: true },
          },
        }),
      ],
    },
    configure: (webpackConfig) => ({
      ...webpackConfig,
      output: {
        ...webpackConfig.output,
        publicPath: "auto",
      },
    }),
  },
};