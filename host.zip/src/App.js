import React, { Suspense } from "react";
import "./App.css";
const TodoList = React.lazy(() => import("TodoModule/Todo")); 
const Todo = React.lazy(() => import("TodoModule/Todo2"));
function App() {
  return (
    <div className="App">
      <p>Host</p>
      <Suspense fallback="Loading...">
        <TodoList /> 
        <Todo/>
      </Suspense>
    </div>
  );
} 
export default App;